predict(model1, data.frame(Home=1, Team= "Burnley",
                           Opponent="Aston Villa"), type="response")
predict(model1, data.frame(Home=0, Team= "Aston Villa",
                           Opponent="Burnley"), type="response")

predict(model1, data.frame(Home=1, Team= "Newcastle",
                           Opponent="Leicester"), type="response")
predict(model1, data.frame(Home=0, Team= "Leicester",
                           Opponent="Newcastle"), type="response")

predict(model1, data.frame(Home=1, Team= "Southampton",
                           Opponent="Tottenham"), type="response")
predict(model1, data.frame(Home=0, Team= "Tottenham",
                           Opponent="Southampton"), type="response")

predict(model1, data.frame(Home=1, Team= "Watford",
                           Opponent="Wolves"), type="response")
predict(model1, data.frame(Home=0, Team= "Wolves",
                           Opponent="Watford"), type="response")

predict(model1, data.frame(Home=1, Team= "Man City",
                           Opponent="Everton"), type="response")
predict(model1, data.frame(Home=0, Team= "Everton",
                           Opponent="Man City"), type="response")

predict(model1, data.frame(Home=1, Team= "Norwich",
                           Opponent="Crystal Palace"), type="response")
predict(model1, data.frame(Home=0, Team= "Crystal Palace",
                           Opponent="Norwich"), type="response")

predict(model1, data.frame(Home=1, Team= "West Ham",
                           Opponent="Bournemouth"), type="response")
predict(model1, data.frame(Home=0, Team= "Bournemouth",
                           Opponent="West Ham"), type="response")

predict(model1, data.frame(Home=1, Team= "Arsenal",
                           Opponent="Man United"), type="response")
predict(model1, data.frame(Home=0, Team= "Man United",
                           Opponent="Arsenal"), type="response")

predict(model1, data.frame(Home=1, Team= "Liverpool",
                           Opponent="Sheffield United"), type="response")
predict(model1, data.frame(Home=0, Team= "Sheffield United",
                           Opponent="Liverpool"), type="response")

predict(model1, data.frame(Home=1, Team= "Sheffield United",
                           Opponent="West Ham"), type="response")
predict(model1, data.frame(Home=0, Team= "West Ham",
                           Opponent="Sheffield United"), type="response")
