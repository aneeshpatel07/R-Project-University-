predict(model1, data.frame(Home=1, Team= "Leicester",
                           Opponent="Chelsea"), type="response")
predict(model1, data.frame(Home=0, Team= "Chelsea",
                           Opponent="Leicester"), type="response")

predict(model1, data.frame(Home=1, Team= "Bournemouth",
                           Opponent="Aston Villa"), type="response")
predict(model1, data.frame(Home=0, Team= "Aston Villa",
                           Opponent="Bournemouth"), type="response")

predict(model1, data.frame(Home=1, Team= "Crystal Palace",
                           Opponent="Sheffield United"), type="response")
predict(model1, data.frame(Home=0, Team= "Sheffield United",
                           Opponent="Crystal Palace"), type="response")

predict(model1, data.frame(Home=1, Team= "Liverpool",
                           Opponent="Southampton"), type="response")
predict(model1, data.frame(Home=0, Team= "Southampton",
                           Opponent="Liverpool"), type="response")

predict(model1, data.frame(Home=1, Team= "Newcastle",
                           Opponent="Norwich"), type="response")
predict(model1, data.frame(Home=0, Team= "Norwich",
                           Opponent="Newcastle"), type="response")

predict(model1, data.frame(Home=1, Team= "Watford",
                           Opponent="Everton"), type="response")
predict(model1, data.frame(Home=0, Team= "Everton",
                           Opponent="Watford"), type="response")

predict(model1, data.frame(Home=1, Team= "West Ham",
                           Opponent="Brighton"), type="response")
predict(model1, data.frame(Home=0, Team= "Brighton",
                           Opponent="West Ham"), type="response")

predict(model1, data.frame(Home=1, Team= "Man United",
                           Opponent="Wolves"), type="response")
predict(model1, data.frame(Home=0, Team= "Wolves",
                           Opponent="Man United"), type="response")

predict(model1, data.frame(Home=1, Team= "Burnley",
                           Opponent="Arsenal"), type="response")
predict(model1, data.frame(Home=0, Team= "Arsenal",
                           Opponent="Burnley"), type="response")

predict(model1, data.frame(Home=1, Team= "Tottenham",
                           Opponent="Man City"), type="response")
predict(model1, data.frame(Home=0, Team= "Man City",
                           Opponent="Tottenham"), type="response")
