predict(model1, data.frame(Home=1, Team= "Arsenal",
                           Opponent="Sheffield United"), type="response")
predict(model1, data.frame(Home=0, Team= "Sheffield United",
                           Opponent="Arsenal"), type="response")

predict(model1, data.frame(Home=1, Team= "Brighton",
                           Opponent="Aston villa"), type="response")
predict(model1, data.frame(Home=0, Team= "Aston Villa",
                           Opponent="Brighton"), type="response")

predict(model1, data.frame(Home=1, Team= "Man City",
                           Opponent="Crystal Palace"), type="response")
predict(model1, data.frame(Home=0, Team= "Crystal Palace",
                           Opponent="Man City"), type="response")

predict(model1, data.frame(Home=1, Team= "Norwich",
                           Opponent="Bournemouth"), type="response")
predict(model1, data.frame(Home=0, Team= "Bournemouth",
                           Opponent="Norwich"), type="response")

predict(model1, data.frame(Home=1, Team= "Southampton",
                           Opponent="Wolves"), type="response")
predict(model1, data.frame(Home=0, Team= "Wolves",
                           Opponent="Southampton"), type="response")

predict(model1, data.frame(Home=1, Team= "West Ham",
                           Opponent="Everton"), type="response")
predict(model1, data.frame(Home=0, Team= "Everton",
                           Opponent="West Ham"), type="response")

predict(model1, data.frame(Home=1, Team= "Newcastle",
                           Opponent="Chelsea"), type="response")
predict(model1, data.frame(Home=0, Team= "Chelsea",
                           Opponent="Newcastle"), type="response")

predict(model1, data.frame(Home=1, Team= "Burnley",
                           Opponent="Leicester"), type="response")
predict(model1, data.frame(Home=0, Team= "Leicester",
                           Opponent="Burnley"), type="response")

predict(model1, data.frame(Home=1, Team= "Liverpool",
                           Opponent="Man United"), type="response")
predict(model1, data.frame(Home=0, Team= "Man United",
                           Opponent="Liverpool"), type="response")

predict(model1, data.frame(Home=1, Team= "Aston Villa",
                           Opponent="Watford"), type="response")
predict(model1, data.frame(Home=0, Team= "Watford",
                           Opponent="Aston Villa"), type="response")