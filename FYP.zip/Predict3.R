predict(model1, data.frame(Home=1, Team= "Crystal Palace",
                           Opponent="Arsenal"), type="response")
predict(model1, data.frame(Home=0, Team= "Arsenal",
                           Opponent="Crystal Palace"), type="response")

predict(model1, data.frame(Home=1, Team= "Chelsea",
                           Opponent="Burnley"), type="response")
predict(model1, data.frame(Home=0, Team= "Burnley",
                           Opponent="Chelsea"), type="response")

predict(model1, data.frame(Home=1, Team= "Everton",
                           Opponent="Brighton"), type="response")
predict(model1, data.frame(Home=0, Team= "Brighton",
                           Opponent="Everton"), type="response")

predict(model1, data.frame(Home=1, Team= "Leicester",
                           Opponent="Southampton"), type="response")
predict(model1, data.frame(Home=0, Team= "Southampton",
                           Opponent="Leicester"), type="response")

predict(model1, data.frame(Home=1, Team= "Man United",
                           Opponent="Norwich"), type="response")
predict(model1, data.frame(Home=0, Team= "Norwich",
                           Opponent="Man United"), type="response")

predict(model1, data.frame(Home=1, Team= "Wolves",
                           Opponent="Newcastle"), type="response")
predict(model1, data.frame(Home=0, Team= "Newcastle",
                           Opponent="Wolves"), type="response")

predict(model1, data.frame(Home=1, Team= "Tottenham",
                           Opponent="Liverpool"), type="response")
predict(model1, data.frame(Home=0, Team= "Liverpool",
                           Opponent="Tottenham"), type="response")

predict(model1, data.frame(Home=1, Team= "Bournemouth",
                           Opponent="Watford"), type="response")
predict(model1, data.frame(Home=0, Team= "Watford",
                           Opponent="Bournemouth"), type="response")

predict(model1, data.frame(Home=1, Team= "Aston Villa",
                           Opponent="Man City"), type="response")
predict(model1, data.frame(Home=0, Team= "Man City",
                           Opponent="Aston Villa"), type="response")

predict(model1, data.frame(Home=1, Team= "Watford",
                           Opponent="Tottenham"), type="response")
predict(model1, data.frame(Home=0, Team= "Tottenham",
                           Opponent="Watford"), type="response")