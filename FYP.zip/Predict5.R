predict(model1, data.frame(Home=1, Team= "Bournemouth",
                           Opponent="Brighton"), type="response")
predict(model1, data.frame(Home=0, Team= "Brighton",
                           Opponent="Bournemouth"), type="response")

predict(model1, data.frame(Home=1, Team= "Crystal Palace",
                           Opponent="Southampton"), type="response")
predict(model1, data.frame(Home=0, Team= "Southampton",
                           Opponent="Crystal Palace"), type="response")

predict(model1, data.frame(Home=1, Team= "Everton",
                           Opponent="Newcastle"), type="response")
predict(model1, data.frame(Home=0, Team= "Newcastle",
                           Opponent="Everton"), type="response")

predict(model1, data.frame(Home=1, Team= "Sheffield United",
                           Opponent="Man City"), type="response")
predict(model1, data.frame(Home=0, Team= "Man City",
                           Opponent="Sheffield United"), type="response")

predict(model1, data.frame(Home=1, Team= "Chelsea",
                           Opponent="Arsenal"), type="response")
predict(model1, data.frame(Home=0, Team= "Arsenal",
                           Opponent="Chelsea"), type="response")

predict(model1, data.frame(Home=1, Team= "Leicester",
                           Opponent="West Ham"), type="response")
predict(model1, data.frame(Home=0, Team= "West Ham",
                           Opponent="Leicester"), type="response")

predict(model1, data.frame(Home=1, Team= "Tottenham",
                           Opponent="Norwich"), type="response")
predict(model1, data.frame(Home=0, Team= "Norwich",
                           Opponent="Tottenham"), type="response")

predict(model1, data.frame(Home=1, Team= "Man United",
                           Opponent="Burnley"), type="response")
predict(model1, data.frame(Home=0, Team= "Burnley",
                           Opponent="Man United"), type="response")

predict(model1, data.frame(Home=1, Team= "Wolves",
                           Opponent="Liverpool"), type="response")
predict(model1, data.frame(Home=0, Team= "Liverpool",
                           Opponent="Wolves"), type="response")

predict(model1, data.frame(Home=1, Team= "West Ham",
                           Opponent="Liverpool"), type="response")
predict(model1, data.frame(Home=0, Team= "Liverpool",
                           Opponent="West Ham"), type="response")