predict(model1, data.frame(Home=1, Team= "Newcastle",
                           Opponent="Everton"), type="response")
predict(model1, data.frame(Home=0, Team= "Everton",
                           Opponent="Newcastle"), type="response")

predict(model1, data.frame(Home=1, Team= "Southampton",
                           Opponent="Crystal Palace"), type="response")
predict(model1, data.frame(Home=0, Team= "Crystal Palace",
                           Opponent="Southampton"), type="response")

predict(model1, data.frame(Home=1, Team= "Watford",
                           Opponent="Aston Villa"), type="response")
predict(model1, data.frame(Home=0, Team= "Aston Villa",
                           Opponent="Watford"), type="response")

predict(model1, data.frame(Home=1, Team= "Norwich",
                           Opponent="Tottenham"), type="response")
predict(model1, data.frame(Home=0, Team= "Tottenham",
                           Opponent="Norwich"), type="response")

predict(model1, data.frame(Home=1, Team= "West Ham",
                           Opponent="Leicester"), type="response")
predict(model1, data.frame(Home=0, Team= "Leicester",
                           Opponent="West Ham"), type="response")

predict(model1, data.frame(Home=1, Team= "Burnley",
                           Opponent="Man United"), type="response")
predict(model1, data.frame(Home=0, Team= "Man United",
                           Opponent="Burnley"), type="response")

predict(model1, data.frame(Home=1, Team= "Arsenal",
                           Opponent="Chelsea"), type="response")
predict(model1, data.frame(Home=0, Team= "Chelsea",
                           Opponent="Arsenal"), type="response")

predict(model1, data.frame(Home=1, Team= "Liverpool",
                           Opponent="Wolves"), type="response")
predict(model1, data.frame(Home=0, Team= "Wolves",
                           Opponent="Liverpool"), type="response")

predict(model1, data.frame(Home=1, Team= "Man City",
                           Opponent="Sheffield United"), type="response")
predict(model1, data.frame(Home=0, Team= "Sheffield United",
                           Opponent="Man City"), type="response")

predict(model1, data.frame(Home=1, Team= "Brighton",
                           Opponent="Chelsea"), type="response")
predict(model1, data.frame(Home=0, Team= "Chelsea",
                           Opponent="Brighton"), type="response")